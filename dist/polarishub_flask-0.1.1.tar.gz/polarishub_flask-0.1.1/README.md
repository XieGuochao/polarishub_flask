How to run?

1. `pip install -r requirement.txt`
2. 
    For Linux based,
    `python3 app.py`

    For others,
    `python app.py`
    (MacOS remains to be tested.)